import UIKit

class Constants {
    static let gray = UIColor(red: 241 / 255, green: 241 / 255, blue: 241 / 255, alpha: 1)
    static let green =  UIColor(red: 190 / 255, green: 245 / 255, blue: 221 / 255, alpha: 1)
    static let darkGray = UIColor(red: 197 / 255, green: 197 / 255, blue: 197 / 255, alpha: 1)
    static let acneColor = UIColor(red: 255 / 255, green: 150 / 255, blue: 197 / 255, alpha: 1)
}

