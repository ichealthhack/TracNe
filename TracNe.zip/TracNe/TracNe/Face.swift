//
//  Face.swift
//  FaceVision
//
//  Created by Joel Oksanen on 17/03/2018.
//  Copyright © 2018 IntelligentBee. All rights reserved.
//

import UIKit

class Face {
    
    static let ratio: CGFloat = 5/3
    
    static func draw(width: CGFloat, center: CGPoint) {
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: width, height: width * ratio))
        imageView.center = center
        
        UIGraphicsBeginImageContextWithOptions(imageView.frame, true, 0.0)
        
        let context = UIGraphicsGetCurrentContext()
        self.draw(in: CGRect(x: 0, y: 0, width: width, height: width * ratio))
        
        context?.translateBy(x: 0, y: self.size.height)
        context?.scaleBy(x: 1.0, y: -1.0)
        
        let finalImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        imageView.image = finalImage
    }
}
