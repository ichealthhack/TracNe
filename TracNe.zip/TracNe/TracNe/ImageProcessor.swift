import UIKit
import Vision

class ImageProcessor {
    
    var imageView = UIImageView()
    var points = [CGPoint]()
    var image: UIImage!
    
    init(image: UIImage) {
        self.image = image
        imageView.image = image
        processImage(image: image)
    }
    
    func processImage(image: UIImage) {
        var orientation:Int32 = 0
        switch image.imageOrientation {
        case .up:
            orientation = 1
        case .right:
            orientation = 6
        case .down:
            orientation = 3
        case .left:
            orientation = 8
        default:
            orientation = 1
        }
        
        let faceLandmarksRequest = VNDetectFaceLandmarksRequest(completionHandler: self.handleFaceFeatures)
        let requestHandler = VNImageRequestHandler(cgImage: image.cgImage!, orientation: CGImagePropertyOrientation(rawValue: UInt32(orientation))! ,options: [:])
        do {
            try requestHandler.perform([faceLandmarksRequest])
        } catch {
            print(error)
        }
    }
    
    func handleFaceFeatures(request: VNRequest, errror: Error?) {
        guard let observations = request.results as? [VNFaceObservation] else {
            fatalError("unexpected result type!")
        }
        
        for face in observations {
            addFaceLandmarksToImage(face)
        }
    }
    
    func addFaceLandmarksToImage(_ face: VNFaceObservation) {
        UIGraphicsBeginImageContextWithOptions(image.size, true, 0.0)
        let context = UIGraphicsGetCurrentContext()
        
        image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
        
        context?.translateBy(x: 0, y: image.size.height)
        context?.scaleBy(x: 1.0, y: -1.0)
        
        let w = face.boundingBox.size.width * image.size.width
        let h = face.boundingBox.size.height * image.size.height
        let x = face.boundingBox.origin.x * image.size.width
        let y = face.boundingBox.origin.y * image.size.height
        let dim: CGFloat = 15
        let halfDim: CGFloat = dim / 2
        
        context?.saveGState()
        context?.setStrokeColor(Constants.green.cgColor)
        context?.setLineWidth(8.0)
        
        points = (face.landmarks!.allPoints?.normalizedPoints)!
        for point in points {
            let center = CGPoint(x: x + CGFloat(point.x) * w, y: y + CGFloat(point.y) * h)
            context?.addEllipse(in: CGRect(x: center.x - halfDim, y: center.y - halfDim, width: dim, height: dim))
        }
        
        context?.drawPath(using: .stroke)
        context?.restoreGState()
        
        // get the final image
        let finalImage = UIGraphicsGetImageFromCurrentImageContext()
        
        // end drawing context
        UIGraphicsEndImageContext()
        
        imageView.image = finalImage
    }
}

