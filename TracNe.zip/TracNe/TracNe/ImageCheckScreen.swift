import UIKit

class ImageCheckScreen: UIView {
    
    let result: (points: [CGPoint], image: UIImageView)
    let okButton = UIButton()
    let retakeButton = UIButton()
    let controller: ViewController
    
    init(result: (points: [CGPoint], image: UIImageView), superView: UIView, controller: ViewController) {
        self.controller = controller
        self.result = result
        super.init(frame: superView.frame)
        self.frame = superView.frame
        self.backgroundColor = UIColor.darkGray
        superView.addSubview(self)
        
        let topBar = UIView(frame: CGRect(x: 0, y: 0, width: frame.width, height: frame.height / 10))
        topBar.backgroundColor = UIColor.darkGray
        self.addSubview(topBar)
        
        let image = result.image
        let ratio = image.image!.size.height / image.image!.size.width
        image.contentMode = .scaleAspectFit
        image.frame = CGRect(x: 0, y: frame.height / 10, width: frame.width, height: ratio * frame.width)
        self.addSubview(image)
        
        let buttonWidth = frame.width / 3
        let buttonHeight = buttonWidth / 2
        let buttonX = (frame.width - buttonWidth * 2) / 3
        let buttonY = frame.height - (frame.height - topBar.frame.height - image.frame.height) / 2
        retakeButton.frame = CGRect(x: buttonX, y: buttonY - buttonHeight / 2, width: buttonWidth, height: buttonHeight)
        retakeButton.backgroundColor = Constants.green
        retakeButton.setTitle("retake", for: .normal)
        retakeButton.setTitleColor(UIColor.darkGray, for: .normal)
        retakeButton.addTarget(self, action: #selector(self.retakeButtonTouchedDown), for: .touchDown)
        retakeButton.addTarget(self, action: #selector(self.retakeButtonTouchedUpOutside), for: .touchUpOutside)
        retakeButton.addTarget(self, action: #selector(self.retakeButtonTouchedUpInside), for: .touchUpInside)
        self.addSubview(retakeButton)
        
        okButton.frame = CGRect(x: 2 * buttonX + retakeButton.frame.width, y: buttonY - buttonHeight / 2, width: buttonWidth, height: buttonHeight)
        okButton.backgroundColor = Constants.green
        okButton.setTitle("continue", for: .normal)
        okButton.setTitleColor(UIColor.darkGray, for: .normal)
        okButton.addTarget(self, action: #selector(self.okButtonTouchedDown), for: .touchDown)
        okButton.addTarget(self, action: #selector(self.okButtonTouchedUpOutside), for: .touchUpOutside)
        okButton.addTarget(self, action: #selector(self.okButtonTouchedUpInside), for: .touchUpInside)
        self.addSubview(okButton)
    }
    
    @objc func okButtonTouchedDown() {
        okButton.backgroundColor = Constants.darkGray
    }
    @objc func okButtonTouchedUpOutside() {
        okButton.backgroundColor = Constants.green
    }
    @objc func okButtonTouchedUpInside() {
        okButton.backgroundColor = Constants.green
        controller.processedImage(result: result)
        
        UIView.beginAnimations(nil, context: nil)
        center.y = center.y + frame.height
        UIView.commitAnimations()
        
        Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.removeFromSuperview), userInfo: nil, repeats: false)
    }
    
    @objc func retakeButtonTouchedDown() {
        retakeButton.backgroundColor = Constants.darkGray
    }
    @objc func retakeButtonTouchedUpOutside() {
        retakeButton.backgroundColor = Constants.green
    }
    
    @objc func retakeButtonTouchedUpInside() {
        retakeButton.backgroundColor = Constants.green
        controller.takePhoto()
        Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.removeFromSuperview), userInfo: nil, repeats: false)
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
