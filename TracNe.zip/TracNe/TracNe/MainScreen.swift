import UIKit

class MainScreen: UIView, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var face: UIImageView!
    var acne = CAShapeLayer()
    let percentage = UILabel()
    let percentageText = UILabel()
    let lowerBar = UIView()
    let cameraShape = CAShapeLayer()
    var camera: UIImageView!
    let cameraButton = UIButton()
    var graph: Graph!
    
    let controller: ViewController
    var image: UIImage!
    
    var acneData = Dictionary<Date, [CGPoint]>()
    
    init(superView: UIView, controller: ViewController) {
        self.controller = controller
        super.init(frame: CGRect())
        frame = superView.frame
        superView.addSubview(self)
        backgroundColor = UIColor.darkGray
        
        face = UIImageView(image: UIImage(named: "face"))
        let faceWidth = frame.width / 2
        let faceHeight = faceWidth * (7/5)
        face.frame = CGRect(x: center.x - faceWidth / 2, y: center.y * (4 / 5) - faceHeight / 2, width: faceWidth, height: faceHeight)
        self.addSubview(face)
        
        let percentageWidth = frame.width / 2
        let percentageHeight = percentageWidth / 1.5
        percentage.frame = CGRect(x: center.x - percentageWidth / 2, y: center.y * (1.2/5) - percentageHeight / 2, width: percentageWidth, height: percentageHeight)
        percentage.text = "-7.3%"
        percentage.font = UIFont(name: "Helvetica", size: 50)
        percentage.textColor = Constants.green
        percentage.textAlignment = .center
        self.addSubview(percentage)
        
        let percentageTWidth = frame.width
        let percentageTHeight = percentageHeight / 2
        percentageText.frame = CGRect(x: center.x - percentageTWidth / 2, y: center.y * (1.7/5) - percentageTHeight / 2, width: percentageTWidth, height: percentageTHeight)
        percentageText.text = "since last week"
        percentageText.font = UIFont(name: "Helvetica", size: 20)
        percentageText.textColor = Constants.gray
        percentageText.textAlignment = .center
        self.addSubview(percentageText)
        
        lowerBar.frame = CGRect(x: 0, y: frame.height * (3/5), width: frame.width, height: frame.height * (2/5))
        lowerBar.backgroundColor = Constants.green
        self.addSubview(lowerBar)
        
        cameraShape.bounds = lowerBar.bounds
        cameraShape.frame = CGRect(x: frame.width / 4, y: frame.height * (2/5) - frame.width / 4, width: frame.width / 2, height: frame.width / 2)
        cameraShape.cornerRadius = frame.width / 4
        cameraShape.backgroundColor = Constants.gray.cgColor
        lowerBar.layer.addSublayer(cameraShape)
        
        camera = UIImageView(image: UIImage(named: "camera"))
        let cameraWidth = frame.width / 8
        let cameraHeight = cameraWidth * (206/256)
        camera.frame = CGRect(x: 0, y: 0, width: cameraWidth, height: cameraHeight)
        camera.center = CGPoint(x: frame.width / 2, y: frame.height - frame.width / 8)
        self.addSubview(camera)
        
        cameraButton.frame = cameraShape.frame
        cameraButton.center = CGPoint(x: frame.width / 2, y: frame.height)
        cameraButton.addTarget(self, action: #selector(self.cameraButtonTouchedDown), for: .touchDown)
        cameraButton.addTarget(self, action: #selector(self.cameraButtonTouchedUpOutside), for: .touchUpOutside)
        cameraButton.addTarget(self, action: #selector(self.cameraButtonTouchedUpInside), for: .touchUpInside)
        self.addSubview(cameraButton)
        
        acne.bounds = face.bounds
        acne.frame = CGRect(x: 0, y: 0, width: face.frame.width, height: face.frame.height)
        face.layer.addSublayer(acne)
        
        graph = Graph(width: frame.width, height: lowerBar.frame.height * (3/5), superView: self, mainScreen: self)
        graph.center = CGPoint(x: center.x, y: frame.height - lowerBar.frame.height + graph.frame.height / 2)
        
        // presentation data:
        acneData.updateValue([CGPoint(x: 0.2, y: 0.3), CGPoint(x: 0.25, y: 0.35), CGPoint(x: 0.7, y: 0.6), CGPoint(x: 0.45, y: 0.8)], forKey: (Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 9))!))
        acneData.updateValue([CGPoint(x: 0.2, y: 0.3), CGPoint(x: 0.25, y: 0.35), CGPoint(x: 0.7, y: 0.6)], forKey: (Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 10))!))
        acneData.updateValue([CGPoint(x: 0.2, y: 0.3), CGPoint(x: 0.25, y: 0.35), CGPoint(x: 0.7, y: 0.6), CGPoint(x: 0.3, y: 0.75)], forKey: (Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 11))!))
        acneData.updateValue([CGPoint(x: 0.2, y: 0.3), CGPoint(x: 0.25, y: 0.35), CGPoint(x: 0.3, y: 0.75)], forKey: (Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 12))!))
        acneData.updateValue([CGPoint(x: 0.2, y: 0.3), CGPoint(x: 0.25, y: 0.35), CGPoint(x: 0.3, y: 0.75)], forKey: (Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 13))!))
        acneData.updateValue([CGPoint(x: 0.2, y: 0.3), CGPoint(x: 0.3, y: 0.75)], forKey: (Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 14))!))
        acneData.updateValue([CGPoint(x: 0.2, y: 0.3), CGPoint(x: 0.3, y: 0.75)], forKey: (Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 15))!))
        acneData.updateValue([CGPoint(x: 0.3, y: 0.75), CGPoint(x: 0.8, y: 0.3)], forKey: (Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 16))!))
        acneData.updateValue([CGPoint(x: 0.3, y: 0.65), CGPoint(x: 0.8, y: 0.3)], forKey: (Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 17))!))
        
        updateFace(date: (Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 17))!))
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func cameraButtonTouchedDown() {
        cameraShape.backgroundColor = Constants.darkGray.cgColor
    }
    @objc func cameraButtonTouchedUpOutside() {
        cameraShape.backgroundColor = Constants.gray.cgColor
    }
    @objc func cameraButtonTouchedUpInside() {
        cameraShape.backgroundColor = Constants.gray.cgColor
        controller.takePhoto()
    }
    
    func updateData(facePoints: [CGPoint], acnePoints: [CGPoint], date: Date) {
        acneData.updateValue([CGPoint(x: 0.3, y: 0.65)], forKey: date) // for presentation only
        percentage.text = "-7.5%" // for presentation only
        updateFace(date: date)
        graph.addData(new: (date, 0.2))
    }
    
    func updateFace(date: Date) {
        if acne.sublayers != nil {
            for subLayer in acne.sublayers! {
                subLayer.removeFromSuperlayer()
            }
        }
        
        let acnePoints = acneData[date]
        for point in acnePoints! {
            let spot = CAShapeLayer()
            spot.bounds = acne.bounds
            let dim: CGFloat = 8
            spot.frame = CGRect(x: point.x * acne.frame.width - dim / 2, y: point.y * acne.frame.height - dim / 2, width: dim, height: dim)
            spot.backgroundColor = Constants.acneColor.cgColor
            spot.cornerRadius = dim / 2
            acne.addSublayer(spot)
        }
    }
    
}
