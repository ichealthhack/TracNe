import UIKit

class Graph: UIView {
    
    var data = [(Date, CGFloat)]()
    let daysShown = 9
    var lowerBarHeight: CGFloat!
    let dateLabel = UILabel()
    let dataLayer = CAShapeLayer()
    let dataView = UIView()
    
    var panPoint = CGPoint()
    var maxPan: CGFloat!
    
    let graphLabelTop = UILabel()
    let graphLabelTop2 = UILabel()
    let graphLabelMiddle = UILabel()
    let graphLabelBottom = UILabel()
    
    let mainScreen: MainScreen!
    
    init(width: CGFloat, height: CGFloat, superView: UIView, mainScreen: MainScreen) {
        self.mainScreen = mainScreen
        super.init(frame: superView.frame)
        self.backgroundColor = Constants.darkGray
        self.frame = CGRect(x: 0, y: 0, width: width, height: height)
        superView.addSubview(self)
        
        lowerBarHeight = frame.height * (1.5 / 10)
        dateLabel.frame = CGRect(x: 0, y: frame.height * (8.5 / 10), width: frame.width, height: lowerBarHeight)
        dateLabel.backgroundColor = Constants.gray
        dateLabel.textAlignment = .center
        dateLabel.textColor = UIColor.darkGray
        dateLabel.font = UIFont(name: "Helvetica", size: 14)
        self.addSubview(dateLabel)
        
        dataView.frame = self.frame
        self.addSubview(dataView)
        
        dataLayer.bounds = frame
        dataLayer.frame = CGRect(x: 0, y: 0, width: frame.width, height: frame.height)
        dataView.layer.addSublayer(dataLayer)
        
        let fade = UIImageView(image: UIImage(named: "fade"))
        fade.frame = CGRect(x: frame.width * (4/5), y: 0, width: frame.width * (1/5), height: frame.height - lowerBarHeight)
        self.addSubview(fade)
        
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 5))!, 0.9))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 6))!, 0.75))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 7))!, 0.8))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 8))!, 0.8))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 9))!, 0.70))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 10))!, 0.65))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 11))!, 0.71))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 12))!, 0.50))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 13))!, 0.43))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 14))!, 0.54))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 15))!, 0.31))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 16))!, 0.25))
        data.append((Calendar(identifier: .gregorian).date(from: DateComponents(calendar: Calendar.current, year: 2018, month: 3, day: 17))!, 0.22))
        
        dateLabel.text = dateToString(date: data.last!.0)
        
        let graphLabelHeight = frame.height / 10
        
        graphLabelTop.frame = CGRect(x: frame.width - frame.width / 5, y: 0, width: frame.width / 5, height: graphLabelHeight)
        graphLabelTop.textAlignment = .center
        graphLabelTop.textColor = UIColor.gray
        graphLabelTop.font = UIFont(name: "Helvetica", size: 14)
        graphLabelTop.text = "100%"
        self.addSubview(graphLabelTop)
        
        graphLabelTop2.frame = CGRect(x: frame.width - frame.width / 5, y: (frame.height - lowerBarHeight) / 4, width: frame.width / 5, height: graphLabelHeight)
        graphLabelTop2.textAlignment = .center
        graphLabelTop2.textColor = UIColor.gray
        graphLabelTop2.font = UIFont(name: "Helvetica", size: 14)
        graphLabelTop2.text = "75%"
        self.addSubview(graphLabelTop2)
        
        graphLabelMiddle.frame = CGRect(x: frame.width - frame.width / 5, y: (frame.height - lowerBarHeight) / 2, width: frame.width / 5, height: graphLabelHeight)
        graphLabelMiddle.textAlignment = .center
        graphLabelMiddle.textColor = UIColor.gray
        graphLabelMiddle.font = UIFont(name: "Helvetica", size: 14)
        graphLabelMiddle.text = "50%"
        self.addSubview(graphLabelMiddle)
        
        graphLabelBottom.frame = CGRect(x: frame.width - frame.width / 5, y: (frame.height - lowerBarHeight) * (3/4), width: frame.width / 5, height: graphLabelHeight)
        graphLabelBottom.textAlignment = .center
        graphLabelBottom.textColor = UIColor.gray
        graphLabelBottom.font = UIFont(name: "Helvetica", size: 14)
        graphLabelBottom.text = "25%"
        self.addSubview(graphLabelBottom)
        
        let lineView = UIView(frame: self.frame)
        self.addSubview(lineView)
        lineView.layer.zPosition = -1
        
        let lines = UIBezierPath()
        lines.move(to: CGPoint(x: frame.width, y: (frame.height - lowerBarHeight) / 4))
        lines.addLine(to: CGPoint(x: -frame.width, y: (frame.height - lowerBarHeight) / 4))
        lines.move(to: CGPoint(x: frame.width, y: (frame.height - lowerBarHeight) / 2))
        lines.addLine(to: CGPoint(x: -frame.width, y: (frame.height - lowerBarHeight) / 2))
        lines.move(to: CGPoint(x: frame.width, y: (frame.height - lowerBarHeight) * (3/4)))
        lines.addLine(to: CGPoint(x: -frame.width, y: (frame.height - lowerBarHeight) * (3/4)))
        let lineLayer = CAShapeLayer()
        lineLayer.bounds = self.layer.bounds
        lineLayer.frame = self.layer.frame
        lineLayer.path = lines.cgPath
        lineLayer.strokeColor = UIColor(red: 170 / 255, green: 170 / 255, blue: 170 / 255, alpha: 1).cgColor
        lineLayer.lineWidth = 1
        lineView.layer.addSublayer(lineLayer)
        
        updateInterface()
        updateMaxPan()
        
        let pan = UIPanGestureRecognizer(target: self, action: #selector(panned))
        self.addGestureRecognizer(pan)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func addData(new: (Date, CGFloat)) {
        data.append(new)
        updateMaxPan()
        updateInterface()
        dataView.center.x = self.center.x
        updateDate()
    }
    
    func updateMaxPan() {
        maxPan = CGFloat (data.count - 1) * (frame.width / CGFloat (daysShown - 1))
    }
    
    func updateInterface() {
        if dataLayer.sublayers != nil {
            for subLayer in dataLayer.sublayers! {
                subLayer.removeFromSuperlayer()
            }
        }
        
        let xD = frame.width / CGFloat (daysShown - 1)
        
        var points = [CGPoint]()
        for i in 0...(data.count - 1) {
            let x = frame.width / 2 - CGFloat (i) * xD
            
            let line = UIBezierPath()
            line.move(to: CGPoint(x: x, y: 0))
            line.addLine(to: CGPoint(x: x, y: frame.height - lowerBarHeight))
            
            let lineLayer = CAShapeLayer()
            lineLayer.bounds = dataLayer.bounds
            lineLayer.frame = dataLayer.frame
            lineLayer.path = line.cgPath
            lineLayer.strokeColor = UIColor.gray.cgColor
            lineLayer.lineWidth = 1
            dataLayer.addSublayer(lineLayer)
            
            let dim: CGFloat = 8
            let rect = CGRect(x: x - dim / 2, y: (1 - data[data.count - 1 - i].1) * (frame.height - lowerBarHeight) - dim / 2, width: dim, height: dim)
            let dot = UIBezierPath(ovalIn: rect)
            
            let dotLayer = CAShapeLayer()
            dotLayer.bounds = dataLayer.bounds
            dotLayer.frame = dataLayer.frame
            dotLayer.path = dot.cgPath
            dotLayer.fillColor = Constants.green.cgColor
            dataLayer.addSublayer(dotLayer)
            
            points.append(CGPoint(x: x, y: (1 - data[data.count - 1 - i].1) * (frame.height - lowerBarHeight)))
        }
        
        let connectingLine = UIBezierPath()
        connectingLine.move(to: points[0])
        for i in 1...(points.count - 1) {
            connectingLine.addLine(to: points[i])
        }
        let connectingLineLayer = CAShapeLayer()
        connectingLineLayer.bounds = dataLayer.bounds
        connectingLineLayer.frame = dataLayer.frame
        connectingLineLayer.path = connectingLine.cgPath
        connectingLineLayer.strokeColor = Constants.green.cgColor
        connectingLineLayer.fillColor = UIColor.clear.cgColor
        connectingLineLayer.lineWidth = 1
        dataLayer.addSublayer(connectingLineLayer)
        
    }
    
    @objc func panned(gesture: UIPanGestureRecognizer) {
        //let target = gesture.view!
        
        switch gesture.state {
        case .began:
            panPoint = dataView.center
        case .changed:
            let translation = gesture.translation(in: self)
            if panPoint.x + translation.x >= frame.width / 2 && panPoint.x + translation.x <= maxPan {
                dataView.center = CGPoint(x: panPoint.x + translation.x, y: dataView.center.y)
            }
            updateDate()
        case .ended:
            dataView.center.x = frame.width / 2 + CGFloat (closestFullMovement()) * (frame.width / CGFloat (daysShown - 1))
            updateDate()
        default: break
        }
    }
    
    func dateToString(date: Date) -> String {
        let components = Calendar.current.dateComponents([.day, .month], from: date)
        return String(describing: components.day!) + "/" + String(describing: components.month!)
    }
    
    func closestFullMovement() -> Int {
        return Int(round(abs(dataView.center.x - self.center.x) / (frame.width / CGFloat (daysShown - 1))))
    }
    
    func updateDate() {
        let date = data[data.count - 1 - closestFullMovement()].0
        dateLabel.text = dateToString(date: date)
        mainScreen.updateFace(date: date)
    }
    
    func getPercentage() -> CGFloat {
        return (data.last!.1 - data[data.count - 7].1) / data[data.count - 7].1
    }
    
}
