// Project missing computer vision for acne and way to quantify acne; some code is for presentation purposes only, although would be easy to extend to real-world use

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    var image: UIImage!
    var mainScreen: MainScreen!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mainScreen = MainScreen(superView: view, controller: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func takePhoto() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .camera
        picker.cameraDevice = .front
        self.present(picker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        dismiss(animated: true, completion: nil)
        image = info[UIImagePickerControllerOriginalImage] as! UIImage
        let processor = ImageProcessor(image: image)
        let resultImage = processor.imageView
        ImageCheckScreen(result: (points: processor.points, image: resultImage), superView: view, controller: self)
    }
    
    func processedImage(result: (points: [CGPoint], image: UIImageView)) {
        mainScreen.updateData(facePoints: result.points, acnePoints: [CGPoint(x: 0.3, y: 0.55), CGPoint(x: 0.75, y: 0.8), CGPoint(x: 0.6, y: 0.2)], date: Date())
    }
    
}

